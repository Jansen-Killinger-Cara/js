export class CalcIMC {
    #nome
    #peso
    #altura

    calcularIMC(peso,altura) {
     //  return Math.round((peso/(altura*altura)),2) //peso/Math.pow(altura,2)
     return (peso/(altura*altura)).toFixed(2)    
    }
    tabelaIMC(resultadoIMC) {
        let categoria = ''; 
        if (resultadoIMC < 18.5) {
            categoria = "Abaixo do Peso!";
        } else if (resultadoIMC < 25) {
            categoria = "Peso Normal.";
        } else if (resultadoIMC < 30) {
            categoria = "Sobrepeso ATENÇÃO!";
        } else if (resultadoIMC < 35) {
            categoria = "Obesidade Grau 1 - ATENÇÃO!";
        } else if (resultadoIMC < 40) {
            categoria = "Obesidade Grau 2 - ATENÇÃO!";
        } else {
            categoria = "Obesidade Grau 3 - Muita ATENÇÃO!";
        }
        return categoria;
    }
    
    //Construtor
    constructor(nome,peso,altura) {
        this.#nome=nome
        this.#peso=peso
        this.#altura=altura
    }

    //getter
    getNome(){
        return this.#nome
    }
    getPeso(){
        return this.#peso
    }
    getAltura(){
        return this.#altura
    }
}