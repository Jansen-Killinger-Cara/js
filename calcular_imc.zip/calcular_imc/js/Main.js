import { CalcIMC } from "./CalcIMC.js";

document.getElementById('frmImc').addEventListener('submit', async function (event) {
  event.preventDefault(); // Impede o envio do formulário

  // Captura os valores do formulário
  const nomeForm = document.getElementById('txtNome').value;
  const pesoForm = parseFloat(document.getElementById('nmbPeso').value);
  const alturaForm = parseFloat(document.getElementById('nmbAltura').value);

  // Cria uma nova instância da classe CalcIMC
  let imc = new CalcIMC(nomeForm, pesoForm, alturaForm);
  let resultadoIMC = imc.calcularIMC(pesoForm, alturaForm); // Calcula o IMC
  let categoriaIMC = imc.tabelaIMC(resultadoIMC); // Determina a categoria do IMC

  // Exibe os resultados no DOM
  document.getElementById('print').innerHTML =
    `Nome: ${imc.getNome()} com o Peso: ${imc.getPeso()} e sua altura de ${imc.getAltura()} com o IMC: ${resultadoIMC} Categoria: ${categoriaIMC}`;
});
