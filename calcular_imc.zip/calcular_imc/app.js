const { MongoClient, ServerApiVersion } = require('mongodb');
const express = require('express');
const app = express();
const port = 3000;

// Rota para o caminho raiz ("/")
app.get('/', (req, res) => {
  res.send('Bem-vindo ao servidor!');
});
// Middleware para servir arquivos estáticos da pasta 'public'
app.use(express.static(path.join(__dirname, 'public')));

// Conexão com MongoDB
const uri = "mongodb+srv://luizhenriquefernandesinfo:Senai119@bancoimc.isnhv.mongodb.net/?retryWrites=true&w=majority&appName=bancoimc";
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  },
});

// Função para conectar ao banco de dados
async function connectToDatabase() {
  try {
    await client.connect();
    console.log("Conectado ao MongoDB com sucesso!");
  } catch (err) {
    console.error("Erro ao conectar ao MongoDB:", err);
    process.exit(1); // Encerra o servidor se a conexão falhar
  }
}

// Função para salvar os dados no MongoDB
async function saveIMCData(nome, peso, altura) {
  try {
    const database = client.db("bancoimc");
    const collection = database.collection("imc");
    const result = await collection.insertOne({ nome, peso, altura });
    console.log(`Documento inserido com o ID: ${result.insertedId}`);
  } catch (error) {
    console.error("Erro ao salvar o IMC no MongoDB:", error);
  }
}

// Inicializar a conexão com o banco de dados
connectToDatabase().then(() => {
  app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
  });
});